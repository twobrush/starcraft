package protoss;

public interface Protoss {
	String getName();
	int getSh();
	int getSt();
	int getAttack();
	int getArmor();
	void setSh(int sh);
}
